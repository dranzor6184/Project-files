<html>
    
		<head>
		  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		  <title>Healthcare & Fitness: Recipes</title>
      <link rel="stylesheet" href="css/img.css">
      <link rel="stylesheet" href="css/words.css">
      <link rel="stylesheet" href="css/effects.css">
		  <link rel="stylesheet" href="css/nav.css">   

      <link rel="stylesheet" href="css/recipemain.css">
	 </head>
	<body>
		
  <header>
  	<div class="p"><a href="index.php"><img src="images/health_logo.jpg"></a></div>
    <div class="nav">
      <div id="rectangle" class="head">
      <ul>
        <li class="home"><a href="index.php">Home</a></li>
        <li class="tutorials sub"><a href="recipe.php">Recipes</a>
          <ul>
            <li><a href="breakfast.php">Breakfast</a></li>
            <li><a href="lunch.php">Lunch</a></li>
            <li><a href="snacks.php">Snacks</a></li>
            <li><a href="dinner.php">Dinner</a></li>
          </ul>
        </li>
        <li class="tutorials sub"><a href="exercise.php">Excercise</a>
          <ul>
            <li><a href="Endurance.php">Endurance</a></li>
            <li><a href="strength.php">Strength</a></li>
            <li><a href="balance.php">Balance</a></li>
		      	<li><a href="flexibility.php">Flexibility</a></li>
          </ul>
        </li>
        <li class="articles"><a href="articles.php">Articles</a></li>
        <li class="contact"><a href="contactus.php">Contact</a></li>
        <li class="login"><a href="home_db.php">Login</a></li>
        </div>
      </ul>
    </div>
  </header>
  <br><br><br><br>

    <div class="recipe">
    <a href="recipe.php"><img src="images/Recipes1.jpg"></a>
    </div>


<div class="l hover10 img1" id="image1"><figure><a href="breakfast.php" style="text-decoration : none; color : #000000;"><img src="images/breakfast.jpg"></figure>
  <div class="desc5">Breakfast</div></a></div>
  <div class="l hover10 img1" id="image2"><figure><a href="lunch.php" style="text-decoration : none; color : #000000;"><img src="images/lunch.jpg"></figure>
  <div class="desc6">Lunch</div></a></div>
  <div class="l hover10 img1" id="image3"><figure><a href="snacks.php" style="text-decoration : none; color : #000000;"><img src="images/snacks.jpg"></figure>
    <div class="desc7">Snacks</div></a></div>
  <div class="l hover10 img1" id="image4"><figure><a href="dinner.php" style="text-decoration : none; color : #000000;"><img src="images/dinner.jpg"></figure>
    <div class="desc8">Dinner</div></a></div>
<br><br><br><br><br><br><br><br><br><br><br><br> <br><br><br><br><br><br> <br><br><br><br><br><br> <br><br>

</body>
</html>