<?php
  session_start();
  
  $host= 'localhost';
    $dbname = 'login_system2';
    $user = 'root'; 
    $pass = '';
  if(!isset($_SESSION["user"])){
  header("Location: login_db.php");
  }
  $result = mysqli_connect($host, $user, $pass);
  if(!$result){
    echo "Connection Problem!";
  }
  $db_check = mysqli_select_db($result , $dbname);
  
  $userName = $_SESSION["user"];
  $query = "SELECT * FROM user WHERE username ='$userName'";
  $row = mysqli_query($result , $query);
  
  $data = mysqli_fetch_assoc($row);
  $firstname = $data["firstname"];
  $middlename = $data["middlename"];
  $lastname = $data["lastname"];
  $email = $data["email"];
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		  <title>Healthcare & Fitness: Home</title>
		  <link rel="stylesheet" href="css/img.css">
		  <link rel="stylesheet" href="css/words.css">
		  <link rel="stylesheet" href="css/nav.css">
		  <link rel="stylesheet" href="css/effects.css">
      <link type="text/css" rel="stylesheet" href="css/slider.css"/>
      <script src="slider.js"></script>
	 </head>
	<body>
		
  <header>
  	<div class="p"><a href="index.php"><img src="images/health_logo.jpg"></a></div>
    <div class="nav">
      <div id="rectangle" class="head">
      <ul>
        <li class="home"><a href="index.php">Home</a></li>
        <li class="tutorials sub"><a href="recipes.php">Recipes</a>
          <ul>
            <li><a href="breakfast.php">Breakfast</a></li>
            <li><a href="lunch.php">Lunch</a></li>
            <li><a href="snacks.php">Snacks</a></li>
            <li><a href="dinner.php">Dinner</a></li>
          </ul>
        </li>
        <li class="tutorials sub"><a href="exercise.php">Excercise</a>
          <ul>
            <li><a href="Endurance.php">Endurance</a></li>
            <li><a href="strength.php">Strength</a></li>
            <li><a href="balance.php">Balance</a></li>
		      	<li><a href="flexibility.php">Flexibility</a></li>
          </ul>
        </li>
        <li class="articles"><a href="articles.php">Articles</a></li>
        <li class="contact"><a href="contactus.php">Contact</a></li>
        <li class="login"><a href="home_db.php">Login</a></li>
        </div>
      </ul>
    </div>
  </header>
  <div class="font">
  	<br><br><br><br><h1>
  		How to Stay Motivated to Keep Exercise Exciting
  	</h1>
	<p>It can be easy to lose your motivation if you get bored with your exercise routine. Here's how to spice up your routine.
So you've done what you thought was the hard part: You started a regular exercise routine to get fit and healthy. But now you're finding out that keeping up with it is as hard as starting out in the first place. You need to keep exercising, but how do you do it without getting bored and losing motivation?
<br><br>
	
</p>
<h1>Motivation to Keep Exercise Exciting</h1>
<p>Ask yourself what makes fitness fun. What motivates you most and keeps you focused and centered on a workout? These methods can help you stay focused and interested in your exercise routine:

Find a buddy. Working out is often more enjoyable when you do it with someone else. Find a friend who will exercise with you, and won�t let you back out of your gym dates.
Set goals and a schedule. If you don't plan time for exercise and dedicate yourself to it, it's hard to stay motivated. Schedule times and dates for workouts on your calendar, and jot down what you plan to do and goals you want to accomplish.
Push yourself. Don't work out to the point of injury, but push yourself during exercise routines � don't give up because you don't feel like it or you're tired. Push yourself to go a little harder or a little longer, and you'll feel great afterward.

<br><br><br>
Ask yourself what makes fitness fun. What motivates you most and keeps you focused and centered on a workout? These methods can help you stay focused and interested in your exercise routine:

Find a buddy. Working out is often more enjoyable when you do it with someone else. Find a friend who will exercise with you, and won�t let you back out of your gym dates.
Set goals and a schedule. If you don't plan time for exercise and dedicate yourself to it, it's hard to stay motivated. Schedule times and dates for workouts on your calendar, and jot down what you plan to do and goals you want to accomplish.
Push yourself. Don't work out to the point of injury, but push yourself during exercise routines � don't give up because you don't feel like it or you're tired. Push yourself to go a little harder or a little longer, and you'll feel great afterward.
<br><br><br>
Read or listen to music. If you're walking on a treadmill or using a stair-climbing machine, try reading so you lose track of the minutes while you're burning calories. Or pump yourself up with some favorite music: high-energy, fast-paced songs can give the boost you need to get through your exercise routine. Create a playlist or CD of songs that motivate you for a workout.
Get in the mindset to exercise regularly
Cut out the routine from your exercise routine. You're more likely to lose motivation if you stick to the same workout routine, so come up with options so that you don't get bored. Walk one day, run another, hop on a bike, and try different aerobic and weight machines.
Where to work out. Your environment can have a big impact on how well you focus on your exercise routine. If you prefer being outside, schedule an exercise program around outdoor activities. If you get too distracted by other people in a health club, try investing in videos or exercise equipment and do your workout at home.
<br><br><br>
Eat for exercise. Don't exercise on an empty stomach, but don't eat a huge meal right before exercising, either. Stick to a healthy, balanced diet for lots of energy, and have a light, healthy snack before a scheduled workout so that you don't feel hungry.
To make working out a part of your lifestyle, you may need to occasionally come up with new and fun ways to exercise. Just keep your end goal in mind � better health, fitness, and happiness � and find ways to enjoy your workout.


</p>


  </div>
	</body>
</html>
