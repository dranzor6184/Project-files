
 <?php
 session_start();
  
  $host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';
  if(!isset($_SESSION["user"])){
  header("Location: login.php");
  }

  $result = mysqli_connect($host, $user, $pass);
  if(!$result){
    echo "Connection Problem!";
  }
  $db_check = mysqli_select_db($result , $dbname);
  $userName = $_SESSION["user"];
  $query2 = ("SELECT `user_id`,`name` FROM `user` WHERE `user_id` =$userName");
  $row2 = mysqli_query($result , $query2);

 $depamt=$_POST['input'];
  $query4="update account set balance = (balance + '$depamt') where atm_card_no=(select atm_card_no from user where user.user_id='$userName') ";
  $row4 = mysqli_query($result , $query4);
  echo "<script language='javascript'>alert('Transaction Successfull!'); window.location.href='atm.php'</script>";
 
unset($_POST['deposit']);
?>