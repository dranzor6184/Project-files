<?php
  session_start();
  
  $host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';
  if(isset($_SESSION["user"])){
  header("Location: profile.php");
  }
  $result = mysqli_connect($host, $user, $pass);
  if(!$result){
    echo "Connection Problem!";
  }
  $db_check = mysqli_select_db($result , $dbname);
  


  ?>
  <html>
<head>
  <link rel="stylesheet" href="nav.css">
  </head>
	<body bgcolor="#1a66ff">
<center>

<style>
          *{
        margin:0;
        padding:0;
      }
      {
        background: url('images/background.jpg') no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
      }
      body{
        margin-top: 30px;
      }
      #login-form{
        margin-top:40px;
      }
      table{
        border:solid #dcdcdc 1px;
        padding:15px;
        box-shadow: 0px 0px 1px rgba(0,0,0,0.2);
        background: url("images/panel-bg.png");
      }
      table tr,td{
        width:400px;
        font-size:24px;
        color: white;
       height:20px;
       
      }
      table tr td input{
        width:300px;
        height:25px;
        border:solid #e1e1e1 1px;
        border-radius:3px;
        text-align: center;
        font-family:Verdana, Geneva, sans-serif;
        font-size:16px;
        background:#f9f9f9;
        transition-duration:0.5s;
        box-shadow: inset 0px 0px 1px rgba(0,0,0,0.4);
      }
      table tr td select{
        width:300px;
        height:25px;
        border:solid #e1e1e1 1px;
        border-radius:3px;
        text-align: center;
        font-family:Verdana, Geneva, sans-serif;
        font-size:16px;
        background:#f9f9f9;
        transition-duration:0.5s;
        box-shadow: inset 0px 0px 1px rgba(0,0,0,0.4);
      }
      table tr td button{
        width:400px;
        height:30px;
        border:0px;
        background:rgba(12,45,78,11);
        background:-moz-linear-gradient(top, #595959 , #515151);
        border-radius:3px;
        box-shadow: 1px 1px 1px rgba(1,0,0,0.2);
        color:#f9f9f9;
        font-family:Verdana, Geneva, sans-serif;
        font-size:18px;
        font-weight:bolder;
        text-transform:uppercase;
      }
      table tr td button:active{
        position:relative;
        top:1px;
      }
      table tr td a{
        text-decoration:none;
        color:white;
        font-family:Verdana, Geneva, sans-serif;
        font-size:18px;
      }
        </style>
<header>
     <div class="nav">
      <div id="rectangle" class="head">
      <ul>
        <li class="home"><a href="index.php">Home</a></li>
        <li class="tutorials sub"><a href="atm.php">ATM INTERFACE</a>
        </li>
        <li class="tutorials sub"><a href="profile.php">Profile</a></li>
         
           <li class="tutorials sub">Accounts
           <ul>
           <li><a href="accounts.php">Accounts: Type</a> 
            <li><a href="accounts2.php">Accounts: Branch</a> 
            </ul>
        </li>
        <li class="login"><a href="form1.php">Register</a></li>
        <li class="contact"><a href="contactus.php">Contact</a></li>
        
        </div>
      </ul>
    </div>
  </header>
  <center><br>
  <div id="login-form">
		<form method="POST" action="connect.php">
		<table align="center" width="40%" border="0">
		<tr align=center>
		<td>Name: </td><td ><br><input type="text" name="c_name" required ><br><br></td>
		</tr> 
          <tr align=center>
		<td>User_id: </td><td><br><input type="text" name="user_id" required><br><br></td>
		</tr>
		  <tr align=center>
		<td>Password: </td><td><br><input type="password" name="pass" required><br><br></td>
		</tr>
		  <tr align=center>
		<td>Contact no: </td><td><br><input type="tel" name="num" required><br><br></td>
		</tr>
		  <tr align=center>
		<td>Email: </td><td><br><input type="email" name="mail" required><br><br> </td>
		</tr>
		  <tr align=center>
		<td>Address: </td><td><br><input type="text" name="addr" required><br><br></td>
		</tr>
    <tr align=center><td>Account Type :</td><td><br>
       <select name="accounts">
        <option value="">Select...</option>
        <option value="savings">Savings</option>
        <option value="current">Current</option>
        <option value="fixed-deposit">Fixed Deposit</option>
        <option value="reccuring-deposit">Recurring Deposit</option>
      </select><br><br>
    </td>
    </tr>
    <tr align=center>
		<td>Atm Card no:</td><td><br><input type="text" name="atm_card" required><br><br></td>
		</tr>
    <tr align=center>
		<td>Atm pin: </td><td><br><input type="text" name="atm_pin" required><br><br></td>
		</tr>
			<tr >
		<td colspan="2" align="center"><button type="submit" name="btn-login">Register</button></td>
		</tr>
		</form></table>
	</body>
</html>
