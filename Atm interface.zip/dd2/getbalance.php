<?php
	$host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';
  if(!isset($_SESSION["user"])){
  header("Location: atm.php");
  }
  $result = mysqli_connect($host, $user, $pass);
  if(!$result){
    echo "Connection Problem!";
  }
  $db_check = mysqli_select_db($result , $dbname);
  $userName = $_SESSION["user"];
  $query2 = ("SELECT `user_id`,`name` FROM `user` WHERE `user_id` =$userName");
  $row2 = mysqli_query($result , $query2);
 $query3= "select balance from account where account.atm_card_no=(select atm_card_no from user where user.user_id='$userName')";
 $row3 = mysqli_query($result , $query3);
 
  $data = $row3->fetch_assoc();
  $balance1=$data['balance'];
  echo "<br><br><br>Your Account Balance is Rs. ";echo $balance1; 
 ?>