<!DOCTYPE html>
<html>
<?php
  
    $actp = $_POST['accounts2']; 
       
    $host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';

    $result = mysqli_connect($host, $user, $pass);
	if(!$result){
		echo "Connection Problem!";
	}
    $db_check = mysqli_select_db($result , $dbname);
    if(!isset($_SESSION["user"])){
  header("Location: index_nologin.php");
  }
    $query2 = "SELECT user_id , name , address , contact_no , email_id , accounttype , atm_card_no FROM user WHERE (accounttype='$actp')";
    $row = mysqli_query($result , $query2);
    if($row->num_rows>0){

        echo "<table align=center width='50%'' border=1>
            <tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Address</th>
            <th>Contact No.</th>
            <th>Email Id</th>
            <th>Account Type</th>
            <th>ATM Card No.</th>
            </tr>";
            while($data = $row->fetch_assoc()) {
            echo "<tr>";
            echo "<td  align =center>".$data['user_id']."</td>";
            echo "<td align =center>".$data['name']."</td>";
            echo "<td align =center>".$data['address']."</td>";
            echo "<td align =center>".$data['contact_no']."</td>";
            echo "<td align =center>".$data['email_id']."</td>";
            echo "<td align =center>".$data['accounttype']."</td>";
            echo "<td align =center>".$data['atm_card_no']."</td>";
            echo "</tr>";
            }
            echo "</table>";
            } else {
            echo "0 results";
            }
        mysqli_close($result);    
?>
</body>
</html>