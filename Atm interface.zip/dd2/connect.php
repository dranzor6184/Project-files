<?php
	session_start();
		$name=$_POST['c_name'];
		$userid=$_POST['user_id'];
		$password=$_POST['pass'];
		$conno=$_POST['num'];
		$email=$_POST['mail'];
		$addr=$_POST['addr'];
		$acctype=$_POST['accounts'];
		$ac=$_POST['atm_card'];
		$ap=$_POST['atm_pin'];


		$host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';
	
    $result = mysqli_connect($host, $user, $pass);     if(!$result){ echo "Connection Problem!";     }     
    $db_check =mysqli_select_db($result , $dbname);
		
		$query=" INSERT INTO user (user_id , name , address , contact_no ,email_id , accounttype , atm_card_no , atm_pin , password,bid) VALUES ('$userid' , '$name', '$addr' , '$conno' , '$email' , '$acctype' , '$ac' , '$ap' , '$password',DEFAULT)";
		$res = mysqli_query($result , $query);
		$query2="INSERT INTO account (acc_no, atm_card_no, balance, account_type) VALUES (DEFAULT,'$ac' ,'0','$acctype')";
		$res2 = mysqli_query($result , $query2);
		if($addr =='thane')
		{
			$query3="UPDATE user SET bid = '1' WHERE user_id = '$userid'";
			$res3 = mysqli_query($result , $query3);
		}
		else{
			$query4="UPDATE user SET bid = '2' WHERE user_id = '$userid'";
			$res4 = mysqli_query($result , $query3);
		}

	if($res){
		echo "<script type='text/javascript'>alert('Registered Successfully!')</script>";
		$_SESSION["user"] = $_POST['User'];
		header("Location:login.php");
		exit();
	}
?> 