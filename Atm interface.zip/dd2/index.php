<?php
  session_start();
  
  $host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';
  if(!isset($_SESSION["user"])){
  header("Location: index_nologin.php");
  }
  $result = mysqli_connect($host, $user, $pass);
  if(!$result){
    echo "Connection Problem!";
  }
  $db_check = mysqli_select_db($result , $dbname);
  $userName = $_SESSION["user"];
  $query2 = ("SELECT `user_id`,`name` FROM `user` WHERE `user_id` =$userName");
  $row2 = mysqli_query($result , $query2);


  ?>
<html>
<head>
  <link rel="stylesheet" href="nav.css">
  </head>
	<body bgcolor="#1a66ff">
<center>

   <header>
     <div class="nav">
      <div id="rectangle" class="head">
      <ul>
        <li class="home"><a href="index.php">Home</a></li>
        <li class="tutorials sub"><a href="atm.php">ATM INTERFACE</a>
        </li>
        <li class="tutorials sub"><a href="profile.php">Profile</a></li>
         
           <li class="tutorials sub">Accounts
           <ul>
           <li><a href="accounts.php">Accounts: Type</a> 
            <li><a href="accounts2.php">Accounts: Branch</a> 
            </ul>
        </li>
        <li class="login"><a href="form1.php">Register</a></li>
        <li class="contact"><a href="contactus.php">Contact</a></li>
        
        </div>
      </ul>
    </div>
  </header><br>
 <h1><font size=30 color=white>WELCOME TO NSM BANK! </h1>
	</body>
</html>
