
<form method=POST action="depamt.php"> 
	<br><br><br><input type='text' name='input' placeholder='ENTER AMOUNT TO BE DEPOSITED' required />
  <button type='submit' name='depsub'>DEPOSIT</button></form>
