  <html>

<style>
          *{
        margin:0;
        padding:0;
      }
      {
        background: url('images/background.jpg') no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
      }
      body{
        margin-top: 50px;
      }
      #login-form{
        margin-top:70px;
      }
      table{
        border:solid #dcdcdc 1px;
        padding:25px;
        box-shadow: 0px 0px 1px rgba(0,0,0,0.2);
        background: url("images/panel-bg.png");
      }
      table tr,td{
        padding:15px;
      }
      table tr td input{
        width:97%;
        height:45px;
        border:solid #e1e1e1 1px;
        border-radius:3px;
        padding-left:10px;
        font-family:Verdana, Geneva, sans-serif;
        font-size:16px;
        background:#f9f9f9;
        transition-duration:0.5s;
        box-shadow: inset 0px 0px 1px rgba(0,0,0,0.4);
      }

      table tr td button{
        width:100%;
        height:45px;
        border:0px;
        background:rgba(12,45,78,11);
        background:-moz-linear-gradient(top, #595959 , #515151);
        border-radius:3px;
        box-shadow: 1px 1px 1px rgba(1,0,0,0.2);
        color:#f9f9f9;
        font-family:Verdana, Geneva, sans-serif;
        font-size:18px;
        font-weight:bolder;
        text-transform:uppercase;
      }
      table tr td button:active{
        position:relative;
        top:1px;
      }
      table tr td a{
        text-decoration:none;
        color:white;
        font-family:Verdana, Geneva, sans-serif;
        font-size:18px;
      }
        </style>

<head>
  <link rel="stylesheet" href="nav.css">
  </head>
  <body bgcolor="#1a66ff">
<center>

  <header>
     <div class="nav">
      <div id="rectangle" class="head">
      <ul>
        <li class="home"><a href="index.php">Home</a></li>
        <li class="tutorials sub"><a href="atm.php">ATM INTERFACE</a>
        </li>
        <li class="tutorials sub"><a href="profile.php">Profile</a></li>
         
           <li class="tutorials sub">Accounts
           <ul>
           <li><a href="accounts.php">Accounts: Type</a> 
            <li><a href="accounts2.php">Accounts: Branch</a> 
            </ul>
        </li>
        <li class="login"><a href="form1.php">Register</a></li>
        <li class="contact"><a href="contactus.php">Contact</a></li>
        
        </div>
      </ul>
    </div>
  </header>
  <center>
 <br>
		
		<h1><font size=30 color=white>WELCOME TO NSM BANK! </h1>
		</center>
	</body>
</html>
