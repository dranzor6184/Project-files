
<form method=POST action="withamt.php"> 
	<br><br><br><input type='text' name='withamount' placeholder='ENTER AMOUNT TO BE WITHDRAWN' required />
  <button type='submit' name='withsub'>WITHDRAW</button></form>
