 <?php
 session_start();
  
  $host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';
  if(!isset($_SESSION["user"])){
  header("Location: login.php");
  }

  $result = mysqli_connect($host, $user, $pass);
  if(!$result){
    echo "Connection Problem!";
  }
  $db_check = mysqli_select_db($result , $dbname);
  $userName = $_SESSION["user"];
  $query2 = ("SELECT `user_id`,`name` FROM `user` WHERE `user_id` =$userName");
  $row2 = mysqli_query($result , $query2);

 $withamt=$_POST['withamount'];
  $query4="select balance from account where atm_card_no=(select atm_card_no from user where user.user_id='$userName') ";
  $row4 = mysqli_query($result , $query4);
  $data = $row4->fetch_assoc();
  $balance1=$data['balance'];
  if($balance1<$withamt){
     echo "<script language='javascript'>alert('INSUFFCIENT BALANCE'); window.location.href='atm.php'</script>";
  }

  elseif($withamt>'10000' || $withamt<'100'){
    echo "<script language='javascript'>alert('YOU CANNOT WITHDRAW MORE THAN RS. 10000 OR LESS THAN RS. 100'); window.location.href='atm.php'</script>";
  }
  else{
    $query5="update account set balance = (balance - '$withamt') where account.atm_card_no=(select user.atm_card_no from user where user.user_id='$userName') ";
    $row4 = mysqli_query($result , $query5);
    echo "<script language='javascript'>alert('Transaction Successfull!'); window.location.href='atm.php'</script>";
    unset($_POST['withdraw']);
  }
?>