<font color=white size=24><b>LOGIN HERE!</b>
		
		<div id="login-form">
		
		<form method = "post" action = "login_db.php">
		<table align="center" width="30%" height="35%" border="0">
		<tr>
		<td><input type="text" name="Username" placeholder="Your UserID" required /></td>
		</tr>
		<tr>
		<td><input type="password" name="Password" placeholder="Your Password" required /></td>
		</tr>
		<tr>
		<td><button type="submit" name="btn-login">Sign In</button></td>
		</tr>
		<tr>
		<td align=center><a href="form1.php">Register Here</a></td>
		</tr>
		</table>
		</form>
		</div>
