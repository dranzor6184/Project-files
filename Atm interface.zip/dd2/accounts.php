<?php

  session_start();
  
    $host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';
    
  if(!isset($_SESSION["user"])){
  header("Location: login.php");
  }
  $result = mysqli_connect($host, $user, $pass);
  if(!$result){
    echo "Connection Problem!";
  }
  $db_check = mysqli_select_db($result , $dbname);
 

  ?>
<html>
<head>
  <link rel="stylesheet" href="nav.css">
  </head>
	<body bgcolor="#1a66ff">
<center>


<style>
          *{
        margin:0;
        padding:0;
      }
      .full{
        background: url('images/background.jpg') no-repeat center center fixed;
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;
      }
      body{
        margin-top: 50px;
      }
      #login-form{
        margin-top:70px;
      }
      table{
        border:solid #dcdcdc 1px;
        padding:25px;
        box-shadow: 0px 0px 1px rgba(0,0,0,0.2);
        background: url("images/panel-bg.png");
      }
      table tr,td{
        padding:15px;
         font-size:24px;
        color: white;
        vertical-align: center;
      }
      table tr td input{
        width:97%;
        height:45px;
        border:solid #e1e1e1 1px;
        border-radius:3px;
        padding-left:10px;
        font-family:Verdana, Geneva, sans-serif;
        font-size:16px;
        background:#f9f9f9;
        transition-duration:0.5s;
        box-shadow: inset 0px 0px 1px rgba(0,0,0,0.4);
      }

      table tr td button{
        width:100%;
        height:45px;
        border:0px;
        background:rgba(12,45,78,11);
        background:-moz-linear-gradient(top, #595959 , #515151);
        border-radius:3px;
        box-shadow: 1px 1px 1px rgba(1,0,0,0.2);
        color:#f9f9f9;
        font-family:Verdana, Geneva, sans-serif;
        font-size:18px;
        font-weight:bolder;
        text-transform:uppercase;
      }
      table tr td button:active{
        position:relative;
        top:1px;
      }
      table tr td a{
        text-decoration:none;
        color:white;
        font-family:Verdana, Geneva, sans-serif;
        font-size:18px;
      }
        </style>
<header>
     <div class="nav">
      <div id="rectangle" class="head">
      <ul>
        <li class="home"><a href="index.php">Home</a></li>
        <li class="tutorials sub"><a href="atm.php">ATM INTERFACE</a>
        </li>
        <li class="tutorials sub"><a href="profile.php">Profile</a></li>
         
           <li class="tutorials sub">Accounts
           <ul>
           <li><a href="accounts.php">Accounts: Type</a> 
            <li><a href="accounts2.php">Accounts: Branch</a> 
            </ul>
        </li>
        <li class="login"><a href="form1.php">Register</a></li>
        <li class="contact"><a href="contactus.php">Contact</a></li>
        
        </div>
      </ul>
    </div>
  </header><br><br><br><br><br><br>
  <center>
    
  <div id="acc-form">
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <table align="center" width="30%" border="0" >
      <tr><td >Account Type :
       <select name="accounts2">
        <option value="savings">Savings</option>
        <option value="current">Current</option>
        <option value="fixed-deposit">Fixed Deposit</option>
        <option value="reccuring-deposit">Recurring Deposit</option>
      </select></td>
      
      <td><button type="submit" name="btn-login">Submit</button></td>
      <br><br>
    </td> 
   
 </form>
</table> 
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
include "getacc.php";
}
?>

</center>
  </body>
</html>
