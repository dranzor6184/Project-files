 <div id="login-form">
    <br>
    <form method = "post" action = "<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <table align="center" width="30%" border="0">
    <tr>
    <td><button type="submit" name="withdraw">WITHDRAW</button></td>
    
    <td><button type="submit" name="deposit">DEPOSIT</button></td>
  
    <td><button type="submit" name="balance">CHECK BALANCE</button></td>
    </tr>
   
    </table>
    </form>
</div>

