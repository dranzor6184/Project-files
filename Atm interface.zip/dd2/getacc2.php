<!DOCTYPE html>
<html>
<?php
  
    $brhid = $_POST['brid']; 
        
    $host= 'localhost';
    $dbname = 'dd';
    $user = 'root'; 
    $pass = '';

    $result = mysqli_connect($host, $user, $pass);
	if(!$result){
		echo "Connection Problem!";
	}
    $db_check = mysqli_select_db($result , $dbname);
    if(!isset($_SESSION["user"])){
  header("Location: index_nologin.php");
  }

$sql1 = "create table branch1 (bid int(5) Primary Key,bname Varchar(10),bcontact int(10))";
$row = mysqli_query($result , $sql1);
$sql_1 = "INSERT INTO branch1 (bid, bname, bcontact)
SELECT bid, bname, bcontact FROM branch
where bid = 1 ";
$row2 = mysqli_query($result ,$sql_1);

$sql2 = "create table branch2 (bid int(5) Primary Key,bname Varchar(10),bcontact int(10))";
$row3= mysqli_query($result ,$sql2);
$sql_2 = "INSERT INTO branch2 (bid, bname, bcontact)
SELECT bid, bname, bcontact FROM branch
where bid = 2 ";
$row4= mysqli_query($result ,$sql_2);


if($brhid == 1)
{
$sql3= "create table user1 (user_id varchar(15) Primary Key, name Varchar(30), accounttype  varchar(20),atm_card_no int(10),bid int(5))";
$row4= mysqli_query($result ,$sql3);
$sql4 = "insert into user1 (select user_id, name, accounttype, atm_card_no,user.bid from user left outer join branch1 on user.bid = branch1.bid where user.bid= 1)";
$row5= mysqli_query($result ,$sql4);
$sql5="select * from user1";
$row6= mysqli_query($result ,$sql5);
if ($row6->num_rows > 0) {

echo "<table align=center width='50%'' border=1>
<tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Account type</th>
            <th>Atm Card No</th>
            <th>Branch id</th>
            
</tr>";
while($data = $row6->fetch_assoc()) {
            echo "<tr>";
            echo "<td  align =center>".$data['user_id']."</td>";
            echo "<td align =center>".$data['name']."</td>";
            echo "<td align =center>".$data['accounttype']."</td>";
            echo "<td align =center>".$data['atm_card_no']."</td>";
            echo "<td align =center>".$data['bid']."</td>";
            echo "</tr>";
            }
            echo "</table>";
            } else {
            echo "0 results";
            }

}

elseif($brhid==2)
{
$sql11= "create table user2 (user_id varchar(15) Primary Key, name Varchar(30), accounttype  varchar(20),atm_card_no int(10),bid int(5))";
$row11= mysqli_query($result ,$sql11);
$sql12 = "insert into user2 (select user_id, name, accounttype, atm_card_no,user.bid from user left outer join branch2 on user.bid = branch2.bid where user.bid= 2)";
$row12= mysqli_query($result ,$sql12);
$sql13="select * from user2";
$row13= mysqli_query($result ,$sql13);
if ($row13->num_rows > 0) {

echo "<table align=center width='50%'' border=1>
<tr>
            <th>User ID</th>
            <th>Name</th>
            <th>Account type</th>
            <th>Atm Card No</th>
            <th>Branch id</th>
            
</tr>";
while($data = $row13->fetch_assoc()) {
            echo "<tr>";
            echo "<td  align =center>".$data['user_id']."</td>";
            echo "<td align =center>".$data['name']."</td>";
            echo "<td align =center>".$data['accounttype']."</td>";
            echo "<td align =center>".$data['atm_card_no']."</td>";
            echo "<td align =center>".$data['bid']."</td>";
            echo "</tr>";
            }
            echo "</table>";
            } else {
            echo "0 results";
            }

}

mysqli_close($result);
?>
</body>
</html>